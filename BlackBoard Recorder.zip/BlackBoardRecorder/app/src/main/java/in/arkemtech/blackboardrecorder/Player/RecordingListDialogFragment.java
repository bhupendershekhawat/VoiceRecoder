package in.arkemtech.blackboardrecorder.Player;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import in.arkemtech.blackboardrecorder.LocalDB.RecordingModels;
import in.arkemtech.blackboardrecorder.R;

/**
 * <p>A fragment that shows a list of items as a modal bottom sheet.</p>
 * <p>You can show this modal bottom sheet from your activity like this:</p>
 * <pre>
 *     RecordingListDialogFragment.newInstance(30).show(getSupportFragmentManager(), "dialog");
 * </pre>
 */
public class RecordingListDialogFragment extends BottomSheetDialogFragment {

    private RecyclerView recyclerView;
    private  RecordItemAdapter adapter;
    RecodingViewModel recodingViewModel;

    public static RecordingListDialogFragment newInstance( ) {
        
        Bundle args = new Bundle();
        
        RecordingListDialogFragment fragment = new RecordingListDialogFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View Fview = inflater.inflate(R.layout.fragment_recording_list_dialog_list_dialog, container, false);
        return Fview;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        recyclerView = view.findViewById(R.id.RCW_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    private class RecordItemAdapter extends RecyclerView.Adapter<RecordItemAdapter.RecordViewHolder>{

       private List<RecordingModels> modelsArrayList;

       public RecordItemAdapter( List<RecordingModels> modelsArrayList) {
           this.modelsArrayList = modelsArrayList;
       }

       @NonNull
       @Override
       public RecordViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
           View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_recording_list_dialog_list_dialog_item, parent,false);
           return new RecordViewHolder(view) ;
       }

       @Override
       public void onBindViewHolder(@NonNull RecordViewHolder holder, int position) {

           RecordingModels recordingModels = modelsArrayList.get(position);

           holder.recodingName.setText(recordingModels.getFilename());

       }

       @Override
       public int getItemCount() {
           return modelsArrayList.size();
       }

       class RecordViewHolder extends RecyclerView.ViewHolder{

         private  TextView recodingName;

            public RecordViewHolder(@NonNull View itemView) {
                super(itemView);

                recodingName = itemView.findViewById(R.id.recodingName);
            }
        }
   }
}