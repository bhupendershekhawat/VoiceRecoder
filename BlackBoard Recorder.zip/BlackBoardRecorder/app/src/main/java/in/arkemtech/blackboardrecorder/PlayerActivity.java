package in.arkemtech.blackboardrecorder;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import in.arkemtech.blackboardrecorder.LocalDB.RecordingModels;
import in.arkemtech.blackboardrecorder.Player.RecodingViewModel;
import in.arkemtech.blackboardrecorder.Player.RecordingListDialogFragment;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.io.IOException;
import java.util.List;

public class PlayerActivity extends AppCompatActivity implements Runnable {

    MediaPlayer mPlayer;
    String mFileName;
    CheckBox Play_checkbox;
    SeekBar seekBar;
    TextView audioTime;

   List<RecordingModels> modelsList;
    RecodingViewModel  recodingViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

//        RecodingViewModel recodingViewModel =  ViewModelProviders.of(PlayerActivity.this).get(RecodingViewModel.class);
//         recodingViewModel = new ViewModelProvider(this).get(RecodingViewModel.class);

        recodingViewModel =  ViewModelProvider.AndroidViewModelFactory.getInstance(this.getApplication()).create(RecodingViewModel.class);

        recodingViewModel.getAllRecodings().observe(this, new Observer<List<RecordingModels>>() {
            @Override
            public void onChanged(List<RecordingModels> recordingModels) {

                modelsList = recordingModels;

            }
        });

        Bundle bundle = getIntent().getExtras();
         mFileName = bundle.getString("mFileName");

        Play_checkbox = findViewById(R.id.Play_checkbox);
        seekBar = findViewById(R.id.seekBar);
        audioTime = findViewById(R.id.audioTime);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int CurrentPosition, boolean b) {

                audioTime.setText(getTimeString(CurrentPosition));

                int x = (int) Math.ceil(CurrentPosition / 1000f);

                if (CurrentPosition == mPlayer.getDuration()){


                    if (!mPlayer.isLooping()){

                        Play_checkbox.setChecked(false);
                    }

                    PlayerActivity.this.seekBar.setProgress(0);

                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {



            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

                    mPlayer.seekTo(seekBar.getProgress());

            }
        });

        CheckBox repeat = findViewById(R.id.repeat);
        repeat.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean checked) {

                if (checked){
                    loopingEnable();
                }else {
                    loopingDisable();
                }

            }
        });

        Play_checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean checked) {
                if (checked){

                    musicplay(Play_checkbox);

                }else {

                    musicpause(Play_checkbox);

                }

            }
        });

        Button show_List = findViewById(R.id.show_List);
        show_List.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        RecordingListDialogFragment bottomSheet = new RecordingListDialogFragment();
                        bottomSheet.show(getSupportFragmentManager(),
                                "bottomSheet");
                    }
                });

        CreateAudio(mFileName);

    }

    private void CreateAudio(String mFileName) {
        mPlayer = new MediaPlayer();

        try {

            mPlayer.setDataSource(mFileName);
            mPlayer.prepare();
            seekBar.setMax(mPlayer.getDuration());
//            mPlayer.start();


        } catch (IOException e) {
            Log.e("TAG", "prepare() failed");
        }
    }



    private void musicplay(View v) {
        mPlayer.start();
        Toast.makeText(PlayerActivity.this, "Music Started", Toast.LENGTH_LONG);

        new Thread(this).start();
    }

    // Pausing the music
    private void musicpause(View v) {
        mPlayer.pause();
        Toast.makeText(PlayerActivity.this, "Music Paused", Toast.LENGTH_LONG);

    }

    // Stoping the music
    private void musicstop(View v) {

        mPlayer.stop();
        Toast.makeText(PlayerActivity.this, "Music Stoped", Toast.LENGTH_LONG);

    }


    private void loopingEnable(){

        mPlayer.setLooping(true);
    }

    private void loopingDisable(){

        mPlayer.setLooping(false);
    }

    private String getTimeString(long millis) {
        StringBuffer buf = new StringBuffer();

        int hours = (int) (millis / (1000 * 60 * 60));
        int minutes = (int) ((millis % (1000 * 60 * 60)) / (1000 * 60));
        int seconds = (int) (((millis % (1000 * 60 * 60)) % (1000 * 60)) / 1000);

        buf
                .append(String.format("%02d", hours))
                .append(":")
                .append(String.format("%02d", minutes))
                .append(":")
                .append(String.format("%02d", seconds));

        return buf.toString();
    }

    public void run() {

        int currentPosition = mPlayer.getCurrentPosition();
        int total = mPlayer.getDuration();



        while (mPlayer != null && mPlayer.isPlaying() && currentPosition < total) {
            try {
                Thread.sleep(1000);
                currentPosition = mPlayer.getCurrentPosition();
            } catch (InterruptedException e) {
                return;
            } catch (Exception e) {
                return;
            }

            seekBar.setProgress(currentPosition);


        }
    }


    // TODO: 1/30/2021 onstop after audio completed
    private void clearMediaPlayer() {
        mPlayer.stop();
        mPlayer.release();
    }

}