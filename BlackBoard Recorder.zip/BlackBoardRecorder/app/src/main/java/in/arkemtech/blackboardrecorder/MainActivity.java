package in.arkemtech.blackboardrecorder;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CheckedTextView;
import android.widget.Chronometer;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

import static android.Manifest.permission.RECORD_AUDIO;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

public class MainActivity extends AppCompatActivity {

    private Button play, stop, record;

    CheckBox Merge;

    // creating a variable for medi recorder object class.
    private MediaRecorder mRecorder;

    // creating a variable for mediaplayer class
    private MediaPlayer mPlayer;

    // string variable is created for storing a file name
    private static String mFileName = null;

    String mFileName1 = null;
    String mFileName2 = null;

    // constant for storing audio permission
    public static final int REQUEST_AUDIO_PERMISSION_CODE = 1;

    Chronometer simpleChronometer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        play = (Button) findViewById(R.id.play);
        stop = (Button) findViewById(R.id.stop);
        record = (Button) findViewById(R.id.record);
        Merge = findViewById(R.id.Merge);
        stop.setEnabled(false);
        play.setEnabled(false);

          // initiate a chronometer
//        simpleChronometer.setFormat("H:MM:SS");



        Merge.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean checked) {

                if (checked){

                    simpleChronometer.stop();
                    pauseRecord();
                    Merge.setText("Resume");

                }else {

                    resumeRecord();
                    Merge.setText("Pause");
                }

            }
        });


        record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                startRecording();

            }
        });


        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                stopRecording();

            }
        });

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                playAudio();
                gotoPlayer();


            }
        });
    }

    private void pauseRecord() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            mRecorder.pause();
        }

    }


    private void gotoPlayer(){

        Intent intent = new Intent(MainActivity.this, PlayerActivity.class);
        intent.putExtra("mFileName", mFileName);
        startActivity(intent);
    }

    private void resumeRecord() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            simpleChronometer.start();
            mRecorder.resume();
        }

    }


    private void startRecording() {
        
        if (CheckPermissions()) {

            simpleChronometer = (Chronometer) findViewById(R.id.simpleChronometer);
            simpleChronometer.start();

            stop.setEnabled(true);
            play.setEnabled(false);
            record.setEnabled(false);



            // we are here initializing our filename variable
            // with the path of the recorded audio file.


            mFileName = Environment.getExternalStorageDirectory().getAbsolutePath();
//            mFileName += "/"+ System.currentTimeMillis()+".3gp";
            mFileName += "/testrecoding.3gp";

            if (mFileName1 == null){

                mFileName1 = mFileName;

            }else if (mFileName2 == null){

                mFileName2 = mFileName;
            }

            // below method is used to initialize
            // the media recorder clss
            mRecorder = new MediaRecorder();

            // below method is used to set the audio
            // source which we are using a mic.
            mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);

            // below method is used to set
            // the output format of the audio.
            mRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);

            // below method is used to set the
            // audio encoder for our recorded audio.
            mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);

            // below method is used to set the
            // output file location for our recorded audio
            mRecorder.setOutputFile(mFileName);
            try {
                // below mwthod will prepare
                // our audio recorder class
                mRecorder.prepare();
            } catch (IOException e) {
                Log.e("TAG", "prepare() failed");
            }
            // start method will start
            // the audio recording.
            mRecorder.start();

            Toast.makeText(MainActivity.this, "Recording Started" , Toast.LENGTH_LONG );


        } else {
            // if audio recording permissions are
            // not granted by user below method will
            // ask for runtime permission for mic and storage.
            RequestPermissions();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        // this method is called when user will
        // grant the permission for audio recording.
        switch (requestCode) {
            case REQUEST_AUDIO_PERMISSION_CODE:
                if (grantResults.length > 0) {
                    boolean permissionToRecord = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean permissionToStore = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                    if (permissionToRecord && permissionToStore) {
                        Toast.makeText(getApplicationContext(), "Permission Granted", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_LONG).show();
                    }
                }
                break;
        }
    }

    public boolean CheckPermissions() {
        // this method is used to check permission
        int result = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);
        int result1 = ContextCompat.checkSelfPermission(getApplicationContext(), RECORD_AUDIO);
        return result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED;
    }

    private void RequestPermissions() {
        // this method is used to request the
        // permission for audio recording and storage.
        ActivityCompat.requestPermissions(MainActivity.this, new String[]{RECORD_AUDIO, WRITE_EXTERNAL_STORAGE}, REQUEST_AUDIO_PERMISSION_CODE);
    }


    public void playAudio() {

        play.setEnabled(false);
        stop.setEnabled(true);
        record.setEnabled(false);

        // for playing our recorded audio
        // we are using media player class.
        mPlayer = new MediaPlayer();
        try {
            // below method is used to set the
            // data source which will be our file name
            mPlayer.setDataSource(mFileName);

            // below method will prepare our media player
            mPlayer.prepare();

            // below method will start our media player.
            mPlayer.start();

            Toast.makeText(MainActivity.this, "Recording Started Playing" , Toast.LENGTH_LONG );

        } catch (IOException e) {
            Log.e("TAG", "prepare() failed");
        }
    }

    public void stopRecording() {

        play.setEnabled(true);
        stop.setEnabled(false);
        record.setEnabled(true);

        simpleChronometer.stop();

        // below method will stop
        // the audio recording.
        mRecorder.stop();


        // below method will release
        // the media recorder class.
        mRecorder.release();
        mRecorder = null;
        Toast.makeText(MainActivity.this, "Recording Stopped" , Toast.LENGTH_LONG );


    }

    public void pausePlaying() {
        // this method will release the media player
        // class and pause the playing of our recorded audio.
        mPlayer.release();
        mPlayer = null;
//        stopTV.setBackgroundColor(getResources().getColor(R.color.gray));
//        startTV.setBackgroundColor(getResources().getColor(R.color.purple_200));
//        playTV.setBackgroundColor(getResources().getColor(R.color.purple_200));
//        stopplayTV.setBackgroundColor(getResources().getColor(R.color.gray));
//        statusTV.setText("Recording Play Stopped");
    }
}

